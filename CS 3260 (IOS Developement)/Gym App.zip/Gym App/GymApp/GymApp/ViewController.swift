//
//  ViewController.swift
//  GymApp
//
//  Created by Jp Otteson on 7/28/20.
//  Copyright © 2020 Jesus Otteson. All rights reserved.
//

import UserNotifications
import UIKit

class ViewController: UIViewController{
    
    @IBOutlet var sundayButton: UIButton!
    @IBOutlet var mondayButton: UIButton!
    @IBOutlet var tuesdayButton: UIButton!
    @IBOutlet var wednesdayButton: UIButton!
    @IBOutlet var thursdayButton: UIButton!
    @IBOutlet var fridayButton: UIButton!
    @IBOutlet var saturdayButton: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

