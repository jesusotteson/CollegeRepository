//
//  sunday.swift
//  GymApp
//
//  Created by Jp Otteson on 8/7/20.
//  Copyright © 2020 Jesus Otteson. All rights reserved.
//

import Foundation

class Sunday {
 
    var id: Int
    var title: String?
    var note: String?
 
    init(id: Int, title: String?, note: String?){
        self.id = id
        self.title = title
        self.note = note
    }
}
