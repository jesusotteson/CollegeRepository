//
//  EntryViewController.swift
//  GymApp
//
//  Created by Jp Otteson on 8/5/20.
//  Copyright © 2020 Jesus Otteson. All rights reserved.
//

import UIKit
import SQLite3

class sundayEntryViewController: UIViewController {

    
    @IBOutlet var titleField: UITextField!
    @IBOutlet var noteField: UITextView!

    public var completion: ((String, String) -> Void)?
    var db: OpaquePointer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleField.becomeFirstResponder()
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(didTapSave))
        
            
        //the database file
           let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
               .appendingPathComponent("sundayDB.sqlite")
    
           //opening the database
           if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
               print("error opening database")
           }
    
           //creating table
           if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS sundayDB (id INTEGER PRIMARY KEY AUTOINCREMENT, storedTitle TEXT, storedNote TEXT)", nil, nil, nil) != SQLITE_OK {
               let errmsg = String(cString: sqlite3_errmsg(db)!)
               print("error creating table: \(errmsg)")
           }
    }

    @objc func didTapSave() {
        if let text = titleField.text, !text.isEmpty, !noteField.text.isEmpty {
            completion?(text, noteField.text)
        }
        
        let enteredTitle = titleField.text
        let enteredNote = noteField.text
        
        //creating a statement
       var stmt: OpaquePointer?

       //the insert query
       let queryString = "INSERT INTO sundayDB (storedTitle, storedNote) VALUES (?,?)"

       //preparing the query
       if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
           let errmsg = String(cString: sqlite3_errmsg(db)!)
           print("error preparing insert: \(errmsg)")
           return
       }

       //binding the parameters
       if sqlite3_bind_text(stmt, 1, enteredTitle, -1, nil) != SQLITE_OK{
           let errmsg = String(cString: sqlite3_errmsg(db)!)
           print("failure binding name: \(errmsg)")
           return
       }

       if sqlite3_bind_text(stmt, 2, enteredNote, -1, nil) != SQLITE_OK{
           let errmsg = String(cString: sqlite3_errmsg(db)!)
           print("failure binding name: \(errmsg)")
           return
       }

       //executing the query to insert values
       if sqlite3_step(stmt) != SQLITE_DONE {
           let errmsg = String(cString: sqlite3_errmsg(db)!)
           print("failure inserting hero: \(errmsg)")
           return
       }

       //emptying the textfields
       titleField.text=""
       noteField.text=""

       print("Workout saved successfully")
    }

}
