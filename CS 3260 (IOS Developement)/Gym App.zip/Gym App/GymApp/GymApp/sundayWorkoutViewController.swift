//
//  sundayWorkoutViewController.swift
//  GymApp
//
//  Created by Jp Otteson on 8/6/20.
//  Copyright © 2020 Jesus Otteson. All rights reserved.
//

import UIKit
import SQLite3

class sundayWorkoutViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {

   
    @IBOutlet var table: UITableView!
    @IBOutlet var label: UILabel!
    
    
    var db: OpaquePointer?
    var sundayList = [Sunday]()
    var models: [(title: String, note: String)] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self

    
       }

        
        // Do any additional setup after loading the view.
    
@IBAction func didTapNewNote() {
    guard let vc = storyboard?.instantiateViewController(identifier: "new") as? sundayEntryViewController else {
            return
        }
        vc.completion = { noteTitle, note in
            self.navigationController?.popViewController(animated: true)
            self.readValues()
            self.label.isHidden = true
            self.table.isHidden = false
            //print([Sunday]())
            
            self.table.reloadData()
        }
        navigationController?.pushViewController(vc, animated: true)
    }

    // Table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sundayList.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sundayCell", for: indexPath) as UITableViewCell
        let sunday: Sunday
        sunday = sundayList[indexPath.row]
        cell.textLabel?.text = sunday.title
        cell.detailTextLabel?.text = sunday.note
        self.table.reloadData()
        return cell
    }
    
    
    func readValues(){
    
           //first empty the list of heroes
           sundayList.removeAll()
    
           //this is our select query
           let queryString = "SELECT * FROM sundayDB"
    
           //statement pointer
           var stmt:OpaquePointer?
    
           //preparing the query
           if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
               let errmsg = String(cString: sqlite3_errmsg(db)!)
               print("error preparing insert: \(errmsg)")
               return
           }
    
           //traversing through all the records
           while(sqlite3_step(stmt) == SQLITE_ROW){
               let id = sqlite3_column_int(stmt, 0)
               let title = String(cString: sqlite3_column_text(stmt, 1))
               let note = sqlite3_column_int(stmt, 2)
    
               //adding values to list
               sundayList.append(Sunday(id: Int(id), title: String(describing: title), note: String(describing: note)))
           }
    
       }


//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        tableView.deselectRow(at: indexPath, animated: true)
//
//        let model = models[indexPath.row]
//
//        // Show note controller
//        guard let vc = storyboard?.instantiateViewController(identifier: "note") as? NoteViewController else {
//            return
//        }
//        vc.navigationItem.largeTitleDisplayMode = .never
//        vc.noteTitle = model.title
//        vc.note = model.note
//        navigationController?.pushViewController(vc, animated: true)
//    }

}
