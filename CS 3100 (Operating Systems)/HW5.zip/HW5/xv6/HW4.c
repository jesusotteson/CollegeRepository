#include "param.h"
#include "types.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"
#include "fs.h"
#include "fcntl.h"
#include "stat.h"
#include "user.h"

int main(void)
{
int magic=gMagic();
printf(1, "current magic number is the following: %d\n",magic);

iMagic(3);

magic = gMagic();
printf(1, "current magic number is the following: %d\n",magic);

geName();
moName("User");
geName();

magic = gMagic();
printf(1, "current magic number is the following: %d\n",magic);

iMagic(3);

magic = gMagic();
printf(1, "current magic number is the following: %d\n",magic);

exit();
}
