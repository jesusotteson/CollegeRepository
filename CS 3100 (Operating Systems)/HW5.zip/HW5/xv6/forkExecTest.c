#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"


int
main (int argc, char *argv[])
{
    if (argc != 2)
    {
        printf(1, "Error: Incorrect number of arguments. Eg.(forkExecTest 100)\n");		
        exit();  
    }
    else
    {
        if (atoi(argv[1]))
        {
            int n = atoi(argv[1]);
            
            int fds[2], pid;
            
            if(pipe(fds) != 0)
            {
                printf(1, "Error\n");
                exit();
            }
            pid = fork();

            if(pid == 0)
            {
                close(fds[1]);
                //setpriority(1);
                int i;
                for (i = 0; i <= n; i++)
                {
                    if(i>0)
                    {
                       printf(1, "highPriority: %d\n", i);
                        
                    }
                }close(fds[0]);
                //exit();
            }
            else if(pid > 0)
            {
                close(fds[0]);
               // setpriority(0);
                int j;
                for (j = 0; j <= n; j++)
                {
                    printf(1, "lowPriority: %d\n", j);
                    wait();
                } 
                //close(fds[0]);
                exit();
            }
          
        }
        else
        {
            printf(1,"Invalid Argument, integer must be positive and greater than 0\n");
		    exit();
        }
    }
    exit();
}
