#include "param.h"
#include "types.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"
#include "fs.h"
#include "fcntl.h"
#include "stat.h"
#include "user.h"



int incrementMagic(int value);
int getMagic(void);
void getCurrentProcessName(void);
void modifyCurrentProcessName(char* newName);

int main(void)
{
int magic=getMagic();
printf(1, "current magic number is the following: %d\n",magic);

incrementMagic(3);

magic = getMagic();
printf(1, "current magic number is the following: %d\n",magic);

getCurrentProcessName();
modifyCurrentProcessName("User");
getCurrentProcessName();

magic = getMagic();
printf(1, "current magic number is the following: %d\n",magic);

incrementMagic(3);

magic = getMagic();
printf(1, "current magic number is the following: %d\n",magic);

exit();
}
