#include "types.h"
#include "user.h"
#include "fcntl.h"

#define N 100

struct test {
    char name;
    int number;
};

void
save(void)
{
    int fd;
    //struct test p;
    //p.name = 's';
    //p.number = 1;

    fd = open("Tom", O_CREATE | O_RDWR);
    if(fd >= 0) {
        printf(1, "JP Otteson\n");
    } else {
        printf(1, "error: create backup file failed\n");
        exit();
    }

    int size = 5;
    if(write(fd, "01234", size) != size){
        printf(1, "error: write to backup file failed\n");
        exit();
    }
    printf(1, "write ok\n");
    close(fd);
}


int
main(void)
{
    save();

    exit();
}
