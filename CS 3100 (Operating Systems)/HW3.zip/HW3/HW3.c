#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
char *fileName = NULL;
int numFork = 0;
int cp[2], i=0;

if(argc != 3)
{
printf("Usage: HW3 numForks fileName\n");
printf("Syntax: HW3 {1,4} fileName\n");
return -1;
}
argv++;

numFork = atoi(*argv);

if( !(numFork == 1 || numFork == 4) )
{
printf("Usage: HW3 numForks fileName\n");
printf("Usage: HW3 {1,4} fileName\n");
return -1;
}

argv++;

fileName = (char *) *argv;

if (pipe(cp) < 0)
{
printf("didn't work, couldn't not establish pipe.\n");
return -1;
}


for (i=0; i<numFork; i++)
{
int pid = fork();
if (pid == 0)
{
printf("this is the child. not the original\n");
close(1); //close stdout
dup2(cp[1], 1); //move stdout to pipe of cp[1]
close(0); //close stdin
close(cp[0]); //close pipe in
execl("findMinMax","findMinMax", fileName,(char *) 0); //note: All the arguments in exec have to be strings.
}
}

{
for(i=0; i<numFork; i++) // loop will run n times (n=5)
wait(NULL);

close(cp[1]); //if you don't close this part of the pipe then the while loop (three lines down) will never return
printf("this is the parent. the 'original.'\n");
char ch;
while( read(cp[0], &ch, 1) == 1)
{
printf("%c",ch);
}
}
printf("This is after the fork.\n");
return 0;
}
