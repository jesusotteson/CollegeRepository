#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

int main(int argc, char * argv[])
{
const char * filename="test.txt";
FILE * ft= fopen(argv[0], "rb") ;
int min = 0;
int max = 0;

if (ft)
{
int pid = getpid();
fseek (ft,0,SEEK_END); //go to end of file
long size = ftell(ft); //what byte in file am I at?
fseek (ft,0,SEEK_SET); //go to beginning of file
int num = (int)size / (int)sizeof(int);
printf("size of the file: %li ,sizeof(int) = %i\n, the number of numbers = %i\n\n", size, (int) sizeof(int), num);
int i;
for(i = 0; i < num; i++){
int temp = 0; // read all the generated numbers
fread(&temp,sizeof(int),1,ft);

if(temp > max)
{
max = temp;
}

/* If current element is smaller than min */
if(temp < min)
{
min = temp;
}
}
fclose( ft ) ;
}
printf("Maximum number in the file is %d\n", max);
printf("Minimum number in the file is %d\n", min);

return 0;
}



