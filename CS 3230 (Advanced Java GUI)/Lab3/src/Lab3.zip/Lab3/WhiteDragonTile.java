public class WhiteDragonTile extends Tile {
    @Override
    public String toString() {
        return "White Dragon";
    }
}