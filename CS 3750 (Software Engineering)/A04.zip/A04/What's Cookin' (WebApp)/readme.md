## Setup
1. Open the folder location in CMD or Terminal and enter `npm install && npm start`
2. Go to http://localhost:3000

## `$ npm: command not found`
If you get this error, it likely means that you don't have node and npm installed on your computer. You can install it [here](https://nodejs.org/en/download/)

## Screenshots
<img src="/screenshots/home.png" alt="Homepage" width="300"/>
<img src="/screenshots/venue.png" alt="Venue" width="300"/>
